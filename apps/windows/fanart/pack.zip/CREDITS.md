# Phosphor fan art pack

Covers for games no box art database has. Each is credited to its source below; the covers belong to their makers. Ask and a cover is taken out.

- **Roll-chan** (NES): hack by Zynk Oxhyde. Cover as posted at https://cdromance.org/nes-roms/roll-chan-hack/.
- **Roll-chan 2** (NES): hack by Zynk Oxhyde. Cover as posted at https://cdromance.org/nes-roms/roll-chan-2-hack/.
- **Roll-chan 3** (NES): hack by Zynk Oxhyde, Kuja Killer. Cover as posted at https://cdromance.org/nes-roms/roll-chan-3-improvement-hack/.
- **Roll-chan 4** (NES): hack by Zynk Oxhyde. Cover as posted at https://retrogametalk.com/repo/nes-roms/roll-chan-4-hack/.
- **Roll-chan 5** (NES): hack by Zynk Oxhyde. Cover as posted at https://retrogametalk.com/repo/nes-roms/roll-chan-5-hack/.
- **Roll-chan 6** (NES): hack by Zynk Oxhyde. Cover as posted at https://retrogametalk.com/repo/nes-roms/roll-chan-6-hack/.
- **Roll-chan No Constancy** (NES): hack by Sfon. Cover as posted at https://cdromance.org/nes-roms/roll-chan-no-constancy-hack/.

Original cover links are in fanart.json ("art"); the copies here are only used when a link stops working.
